<?php
/**
 * File name: StorePaymentRequest.php
 * Last modified: 02/02/22, 9:14 PM
 * Author: NearCraft - https://codecanyon.net/user/nearcraft
 * Copyright (c) 2022
 */

namespace App\Http\Requests\Admin;


class StorePaymentRequest
{

}
