<?php
/**
 * File name: ExamSessionCardTransformer.php
 * Last modified: 25/05/22, 5:10 PM
 * Author: NearCraft - https://codecanyon.net/user/nearcraft
 * Copyright (c) 2022
 */

namespace App\Transformers\Platform;


class ExamSessionCardTransformer
{

}
