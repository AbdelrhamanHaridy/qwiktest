<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\RazorPay\\Providers\\RazorPayServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\RazorPay\\Providers\\RazorPayServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);