<?php return array (
  'providers' => 
  array (
  ),
  'eager' => 
  array (
  ),
  'deferred' => 
  array (
  ),
);